package com.quartz.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.slf4j.LoggerFactory;
import org.lwjgl.glfw.GLFW;

public final class QuartzModClient implements ClientModInitializer {
    private static KeyMapping emoteWheel;
    private static KeyMapping openMenu, stopwatch;

    @Override
    public void onInitializeClient() {
        QuartzConfig.load();
        QuartzShotPreview.start();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.quartz.open_menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC));
        var quartzKeys = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("quartz", "client"));
        emoteWheel = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.quartz.emote_wheel", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, quartzKeys));
        QuartzSocial.register();
        stopwatch = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "Quartz · Stopwatch", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K,
                KeyMapping.Category.MISC));
        net.fabricmc.fabric.api.event.player.AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player == player && QuartzHudModule.REACH.settings().enabled) QuartzHud.attack(client, target);
            return net.minecraft.world.InteractionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            QuartzStyle.tick();
            QuartzMotion.tick(client);
            QuartzSocial.tick(client);
            while (emoteWheel.consumeClick()) {
                if (client.player != null && client.screen == null) client.setScreen(new QuartzEmoteWheel(emoteWheel));
            }
            QuartzTitleScreen.replaceVanilla(client);
            QuartzWardrobe.tick();
            QuartzHud.tick(client);
            while (stopwatch.consumeClick()) {
                if (client.player != null && QuartzHudModule.STOPWATCH.settings().enabled) QuartzHud.toggleStopwatch();
            }
            QuartzShotPreview.tick();
            while (openMenu.consumeClick()) {
                if (client.screen == null && client.player != null) {
                    try {
                        client.setScreen(new QuartzMenuScreen(null));
                    } catch (RuntimeException error) {
                        LoggerFactory.getLogger("Quartz Client").error("Could not open the Quartz mods screen", error);
                        client.setScreen(null);
                        client.player.displayClientMessage(QuartzText.of("Could not open Quartz menu. See the game log.",
                                "Nie udało się otworzyć menu Quartz. Sprawdź dziennik gry."), false);
                    }
                }
            }
        });
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("quartz", "in_game_hud"), (graphics, tickCounter) -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player != null && !(client.screen instanceof QuartzHudEditorScreen)) QuartzHud.inGame(graphics, client);
            if (!client.options.hideGui) QuartzShotPreview.popup(graphics);
        });
    }
}
